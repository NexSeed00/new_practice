# HTML / CSSを使ったシンプルなウェブサイトの制作

以下のリンクと同じ見た目のウェブサイトを作ります。
- [Welcome to NexSeed](https://heuristic-kilby-bf0e3e.netlify.app)

![Welcome to NexSeed](./assets/img/welcome_to_nexseed.jpg)
