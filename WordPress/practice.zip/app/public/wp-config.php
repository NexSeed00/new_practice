<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '+wJq23dDE5BInfwP2OqSTOOE5xuLWn+07T+EZOl53Hmxtc6yUKLLK0DmbKdm54jU1RNQ53jvWyaY9US1Mp2RVg==');
define('SECURE_AUTH_KEY',  'afTLHZz5emvDx3eRNuESzBMNCslL2mdVboxmE+PNYppyfaKTooLR4Qm8Tvri1QxrQ0I6G1oKO4AUVNY23xtISA==');
define('LOGGED_IN_KEY',    'oX9PK6rrrET3qPuml6P2nYL0ZCybu8ZXJ4KGgdPRhtWOzzvclZ9xp/TGBYESEsHfgIcpEUnAZ8K6Rt+ckfekCQ==');
define('NONCE_KEY',        '0uHvPnwyXmJy1m384C/lXvu/cCOFbsFT71pkgsFFFNAOBvGL+2qN1HkMHUr80f7x7gooM9fTVSD/PqCNDxzTVw==');
define('AUTH_SALT',        'COkuqsobF59aEc22YrqClb7zlnYoJk9hwz7Iqk1A3zXQELKLS8eDlBgXR7g+A5j4eJH4av6kxVPC1ay3dJj8cg==');
define('SECURE_AUTH_SALT', 'la6ed7c8N2bOjxQCRJBVS9MtYfs/v72B5DfKadFGNTSgrRtyfx0YMfvsvWM9e54yDiJBCFAX1asslMT9YMf0Sw==');
define('LOGGED_IN_SALT',   'MtvleNS018IzlJYbKxK4IH15CJopY7cIu4hbfYFzNpTiNXxZDVcatKazvNdcRudNfUjZjKYGJdByjZ0adsYGSA==');
define('NONCE_SALT',       'XX0b/NgNQZlizm89gZRajP3jpd3zV0T8AE5Nq/D6xIjCWIKq8WLU/QRTWAXvXLT4EJ7wpimmS8TpvX7L2oxtBw==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
