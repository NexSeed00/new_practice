$(function() {
  $("#btn").on("click", function() {
    const inputValue = $("#input").val();
    console.log(inputValue);

    if (inputValue !== "") {
      const newTask = $("<li>");
      $(newTask).addClass("list").text(inputValue);
      
      $(".todo-list").append(newTask);

      $("#input").val("");

      const deleteBtn = $("<div>");
      $(deleteBtn).addClass("delete").text("Delete");

      $(newTask).append(deleteBtn);

      $(deleteBtn).on("click", function() {
        $(this).parent().remove();
      });
    }
  });
});
