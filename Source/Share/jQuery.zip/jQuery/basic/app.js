// Q1
// const win_width = window.innerWidth;
// alert(win_width);


// Q2
// let num1 = 5;
// let num2 = 8;
// alert(num2 - num1);

// Q3
// let text1 = 'リンゴ・グレープ';
// let text2 = 'バナナ';
// let my_fruits = (text1 + text2).replace('グレープ', '');

// alert(my_fruits);

// Q4
// setTimeout(function() {
//   alert('5秒経過');
// }, 5000);

// Q5
// const fruits = ["リンゴ", "グレープ", "バナナ"];
// alert(fruits[1]);

// Q6
// $(function(){
//   alert('liタグの数は' + $('li').length + '個です！');
// });

// Q7
// $(function() {
//   $('p').click(function() {
//     $(this).toggleClass('is-active');
//   });
// })

//Q8
// $(function() {
//   $('.target').prepend('<p>テキスト1</p>');
// })

// Q9
// $(function() {
//   $('.target').append('<p>テキスト6</p>');
// })

// Q10
// $(function() {
//   $('.trigger').click(function() {
//     $('.target').show();
//   });
// })

// Q11
// $(function() {
//   $('.trigger').click(function() {
//     $('.target').hide();
//   });
// })

// Q12
// $(function() {
//   $('.trigger').click(function() {
//     $('.target').fadeIn("2500");
//   });
// })

// Q13
// $(function() {
//   $('.trigger').click(function() {
//     $('.target').fadeOut("slow");
//   });
// })