<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Twitter</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  <link href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('css/timeline.css')); ?>">
  <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</head>
<body>
  <div id="app">
    <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php echo e(config('app.name', 'Twitter')); ?>

            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">

                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
  </div>
  <div class="wrapper">
    <form action="/timeline" method="post">
      <?php echo csrf_field(); ?>
      <div class="post-box">
        <input type="text" name="tweet" placeholder="今なにしてる?">
        <button type="submit" class="submit-btn">ツイート</button>
      </div>
    </form>

    <div class="tweet-wrapper">
      <?php $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tweet-box">
          <a href="<?php echo e(route('show', [$tweet->user->id])); ?>"><img src="<?php echo e(asset('storage/images/'. $tweet->user->avatar)); ?>" alt=""></a>
          <div><?php echo e($tweet->tweet); ?></div>
          <div class="destroy-btn">
            <?php if($tweet->user_id == Auth::user()->id): ?>
              <form action="<?php echo e(route('destroy', [$tweet->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="submit" value="削除">
              </form>
            <?php endif; ?>
          </div>
        </div>
        <div style="padding:10px 40px">
          <?php if($tweet->likedBy(Auth::user())->count() > 0): ?>
          <a href="/likes/<?php echo e($tweet->likedBy(Auth::user())->firstOrFail()->id); ?>"><i class="fas fa-heart-broken"></i></a>
          <?php else: ?>
          <a href="/tweets/<?php echo e($tweet->id); ?>/likes"><i class="far fa-heart"></i></a>
          <?php endif; ?>
          <?php echo e($tweet->likes->count()); ?>

        </div> 
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($tweets->links()); ?>

    </div>
  </div>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Twitter/resources/views/timeline.blade.php ENDPATH**/ ?>