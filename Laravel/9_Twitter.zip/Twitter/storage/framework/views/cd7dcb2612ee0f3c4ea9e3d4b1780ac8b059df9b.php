<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Twitter</title>
  <link href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('css/timeline.css')); ?>">
</head>
<body>
  <div class="wrapper">
    <form action="/timeline" method="post">
      <?php echo csrf_field(); ?>
      <div class="post-box">
        <input type="text" name="tweet" placeholder="今なにしてる?">
        <button type="submit" class="submit-btn">ツイート</button>
      </div>
    </form>

    <div class="tweet-wrapper">
      <?php $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tweet-box">
          <a href="<?php echo e(route('show', [$tweet->user->id])); ?>"><img src="<?php echo e(asset('storage/images/'. $tweet->user->avatar)); ?>" alt=""></a>
          <div><?php echo e($tweet->tweet); ?></div>
          <div class="destroy-btn">
            <?php if($tweet->user_id == Auth::user()->id): ?>
              <form action="<?php echo e(route('destroy', [$tweet->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="submit" value="削除">
              </form>
            <?php endif; ?>
          </div>
        </div>
        <div style="padding:10px 40px">
          <?php if($tweet->likedBy(Auth::user())->count() > 0): ?>
          <a href="/likes/<?php echo e($tweet->likedBy(Auth::user())->firstOrFail()->id); ?>"><i class="fas fa-heart-broken"></i></a>
          <?php else: ?>
          <a href="/tweets/<?php echo e($tweet->id); ?>/likes"><i class="far fa-heart"></i></a>
          <?php endif; ?>
          <?php echo e($tweet->likes->count()); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Twitter/resources/views/timeline.blade.php ENDPATH**/ ?>