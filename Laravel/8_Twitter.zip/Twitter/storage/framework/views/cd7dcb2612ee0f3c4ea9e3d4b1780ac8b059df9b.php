<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Twitter</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/timeline.css')); ?>">
</head>
<body>
  <div class="wrapper">
    <form action="/timeline" method="post">
      <?php echo csrf_field(); ?>
      <div class="post-box">
        <input type="text" name="tweet" placeholder="今なにしてる?">
        <button type="submit" class="submit-btn">ツイート</button>
      </div>
    </form>

    <div class="tweet-wrapper">
      <?php $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tweet-box">
          <a href="<?php echo e(route('show', [$tweet->user->id])); ?>"><img src="<?php echo e(asset('storage/images/'. $tweet->user->avatar)); ?>" alt=""></a>
          <div><?php echo e($tweet->tweet); ?></div>
          <div class="destroy-btn">
            <?php if($tweet->user_id == Auth::user()->id): ?>
              <form action="<?php echo e(route('destroy', [$tweet->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="submit" value="削除">
              </form>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Twitter/resources/views/timeline.blade.php ENDPATH**/ ?>